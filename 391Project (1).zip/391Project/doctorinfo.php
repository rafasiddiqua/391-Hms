<?php
   $DoctorsName = $_POST['docname'];
    $Email = $_POST['email'];
   $Contactno = $_POST['contactno'];
   $Desigcnation = $_POST['desigcnation'];
    $Fees = $_POST['fees'];
    $AppointmentDate = $_POST['appointment'];
    
//database connection
   $conn = new mysqli('localhost', 'root', '','hms');
   if($conn->connect_error){
        die('connection failed : '.$conn->connect_error);
    }else{
    	$stmt = $conn->prepare("insert into doctorinfo(docname, email, contactno, desigcnation, fees, appointment) values(?, ?, ?, ?, ?, ?)");
    	$stmt->bind_param("ssisis", $DoctorsName, $Email, $Contactno, $Desigcnation,  $Fees, $AppointmentDate);
    	$stmt->execute();

      
    	echo "Doctors Information Updated";
      echo "<script> location.href='appointmentinfo.html'; </script>";

    	$stmt->close();
    	$conn->close();
    }
 ?>