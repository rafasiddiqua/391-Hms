<?php
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "hms";
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    if(isset($_GET['eamil'])){
        $id = $_GET['eamil'];
        $sql = "SELECT * FROM appointment WHERE email='$email'";
        $result = $conn->query($sql);

        $data = mysqli_fetch_array($result);
    }
?>
<!DOCTYPE HTML>
<html>

<head>
    <title>HMS</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
    <div class="index">
        <form action="input.php" method="post" class="form">
            <input type="hidden" name="update" value="1">
            <input type="hidden" name="id" value="<?php echo $data['id'] ?>">
            <table>
                <tr>
                    <td id="name">Name :</td>
                    <td id="namebox"><input type="text" name="name" value="<?php echo $data['name'] ?>"></td>
                </tr>
                <tr>
                    <td id="docname">DoctorsName:</td>
                    <td id="docnamebox"><input type="text" name="docname" value="<?php echo $data['docname'] ?>"></td>
                </tr>
            
                <tr>
                    <td id="date">Date:</td>
                    <td id="appointmentbox"><input type="text" name="appointment" value="<?php echo $data['date'] ?>"></td>
                </tr>
                <tr>
                    <td id="address">Fees :</td>
                    <td id="feesbox"><input type="text" name="fees" value="<?php echo $data['fees'] ?>"></td>
                </tr>
                <td id="prescription">Prescription :</td>
                <td id="prescription">
                    <input type="pdf" name="prescription" value="<?phpheader('Content-Disposition: attachment; filename="gfgpdf.pdf"'); $imagpdf = file_put_contents($image, file_get_contents($file)); echo $data;imagepdf]?>"
                </td>
                <tr>

                 <td id="btn"><input type="submit" value="Update"></td>
                </tr>
            </table>
        </form>
    </div>
</body>

</html>
header('Content-Disposition: attachment; filename="gfgpdf.pdf"');
  
$imagpdf = file_put_contents($image, file_get_contents($file)); 
  
echo $imagepdf;
?>