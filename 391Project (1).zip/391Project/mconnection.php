
<?php

if(isset($_POST['Search']))
{
   $valueToSearch =$_POST['valueToSearch'];
   $query = "SELECT * FROM `doctorinfo` WHERE CONCAT(`mname`, `email`, `contactno`, `degicnation`, `fees`, `appointmrnt`)LIKE '%".$valueToSearch."%'";
   $search_result = filterTable($query);
}
else{
    $query ="SELECT * From 'personalinfo'";
    $search_result = filterTable ($query);
}
function filterTable($query){
    $connect = mysqli_connect("localhost", "root", "", "hms");
    $filter_Result = mysqli_query($connect, $query);
    return $filter_Result;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>HMS</title>
    <link rel="icon" type="text/css" href="img/HMS.jpg"></link>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="css/mdb.min.css" rel="stylesheet">
    <!-- Your custom styles (optional) -->
    <link href="css/style.css" rel="stylesheet">
   <style>
		table,tr,th,td
		{
			border: 1px solid black;
			padding: 20px;
			text-align: center;
			margin: 50px;
		}
	</style>
</head>

<body>
    <div>

        <!-- navbar -->
  <nav class="navbar navbar-expand-lg fixed-top">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
        <a class="navbar-brand" href="#"><img src="HMS.jpg" style="width:1500px;height:550px;"></a>
        <ul class="navbar-nav ml-auto mt-lg-0">
        	<li class="nav-item active">
                <a class="nav-link" href="index.html">Home <span class="sr-only">(current)</span></a>
            </li>
            
            <li class="nav-item">
                <a class="nav-link" href="registration.htm">Registration</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="signin.html">Sign In</a>
            </li>
        </ul>
    </div>
</nav>
<!-- navbar ends -->

<div class="card" style="background-image: url('img/login.png'); background-size: cover; height: auto; width: auto;">
	
<div class="container mt-5 pt-5">
	<center>
<form action="mconnection.php" method="POST">
		<input type="text" name="valueToSearch" placeholder="Give paitent name"><br><br>
		<input type="Submit" name="Search" value="Show User medicine Information"><br><br>
		<H1 Style="Color:black" ><b>User's Medicine Informations are shown below.</b></H1>
		<table>
			<tr>
				<th>MName</th>
				<th>Cost</th>
				<th>Timelimtstart</th>
				<th>Timelimitend</th>
				<th>Prescription</th>
				</tr>
		<?php while ($row = mysqli_fetch_array($search_result)):?>
			<td><?php echo $row['mname'];?></td>
			<td><?php echo $row['cost'];?></td>
			<td><?php echo $row['timelimtstart'];?></td>
			<td><?php echo $row['timelimitend' ];?></td>
			<td><?php echo $row['prescription'];?></td>
			
		<?php endwhile;?>
		</table>
	</form>
	<h1 style="color: black">You Can Also Check User's Basic Info Filtered From All Database.</h1>
    <a href="userinfo.html" class="btn btn-dark b1" tabindex="-1" role="button" aria-disabled="true">Show User Basic Info</a>
</center>
	</div>

</body>
</html>
