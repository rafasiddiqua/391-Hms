<?php
    session_start();
    $host = "localhost";
    $dbUsername = "root";
    $dbPassword = "";
    $dbname = "hms";
    //create connection
    $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);
    $sql = "SELECT * FROM appointment";
    $result = $conn->query($sql);
?>

<?php if($_SESSION["adminlogin"] == 'true'){?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.0/css/bootstrap.min.css" integrity="sha512-F7WyTLiiiPqvu2pGumDR15med0MDkUIo5VTVyyfECR5DZmCnDhti9q5VID02ItWjq6fvDfMaBaDl2J3WdL1uxA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
   
    <title>Admin panel</title>
    
    <link href="style.css" rel="stylesheet">
   
</head>

<body>
<div class="container" style="margin-top:50px;">
        <button style="float:right"><a href="logout.php">Logout</a></button>
        <h3 style="text-align:center">Paitent Record</h3>
		<table class="table table-striped" style="margin-top:30px">
			 <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Doctorsname</th>
                <th>Date</th>
                <th>Fees</th>
                <th>Mname</th>
                <th>Prescription</th>
            </tr>
            <?php $i=1; while($row = $result->fetch_assoc()) {?>
            <tr>
                <td><?php echo $i;?></td>
                <td><?php echo $row['name']?></td>
                <td><?php echo $row['email']?></td>
                <td><?php echo $row['docname']?></td>
                <td><?php echo $row['date']?></td>
                <td><?php echo $row['fees']?></td>
                <td><?php echo $row['mname']?></td>
                <td><?php echo $row['prescription']?></td>
                <td>
                    <td><a href="edit.php?email=<?php echo $row['email']; ?>">Edit</a></td>
                </td>
            </tr>
            <?php $i++; }?>
		</table>	
</div>
  <td><a href="searchinfo.html?email=<?php echo $row['email']; ?>">Edit</a></td>
                </td>

</body>
</html>
<?php }else{
    header("Location: sign_in.php");
}?>