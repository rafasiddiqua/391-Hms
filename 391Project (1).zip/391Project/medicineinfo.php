<?php
   $Mname = $_POST['mname'];
    $Cost = $_POST['cost'];
   $Timelimitstart= $_POST['timelimitstart'];
   $Timelimitend= $_POST['timelimitend'];
    
    
//database connection
   $conn = new mysqli('localhost', 'root', '','hms');
   if($conn->connect_error){
        die('connection failed : '.$conn->connect_error);
    }else{
    	$stmt = $conn->prepare("insert into medicineinfo(mname, cost, timelimitstart, timelimitend) values(?, ?, ?, ?)");
    	$stmt->bind_param("ssisi", $Mname, $Cost, $Timelimitstart, $Timelimitend);
    	$stmt->execute();

      
    	echo "Medicine Information Updated";
      echo " All Information Updated";

    	$stmt->close();
    	$conn->close();
    }
 ?>